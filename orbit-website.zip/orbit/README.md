# Orbit — NEET & JEE study space

A responsive, multi-page website built with **plain HTML, CSS, and JavaScript**. No React, build tools, APIs, CDN libraries, or external fonts are required.

## Run locally

Extract this entire folder. From inside it, run:

```sh
python3 -m http.server 3000
```

Then open `http://localhost:3000` in your browser. On Windows, `py -m http.server 3000` also works when Python is installed. VS Code Live Server or any static hosting service can serve the same files without changes.

Opening `index.html` directly can display the site, but serving it over HTTP is recommended for consistent storage across pages.

## Pages

- `index.html`: overview, subject progress, quick practice and today's plan
- `materials.html`: searchable, subject-filtered revision guides
- `tests.html`: subject-wise and mixed-subject timed practice
- `planner.html`: dated study tasks and focus timer
- `progress.html`: real results, answer review and CSV export
- `bookmarks.html`: saved study guides

## Practice tests

- 64 original foundation-level questions: 16 each for Physics, Chemistry, Biology and Mathematics.
- NEET selects Physics, Chemistry and Biology. JEE selects Physics, Chemistry and Mathematics.
- Choose 8, 12 or 16 questions with 90 seconds per question.
- Fisher–Yates shuffles the question pool and each question's answer options independently. Questions are sampled without replacement within each attempt. Random attempts can share questions.
- Correctness travels with the answer object, so shuffling does not break marking.
- +4 correct, −1 incorrect, 0 skipped. Incorrect answers can produce a negative total.
- Navigate between questions, clear answers, confirm submission, and read explanations afterward.
- Tests automatically submit at the deadline while the test page is open. If you leave the page, the deadline keeps running; returning to it resumes the test or submits it if expired.
- Current test state is held in sessionStorage for same-tab refresh recovery.

## Study tools

12 concise revision guides include core concepts, formulas, worked examples, and tips. You can download text notes, mark guides as complete and bookmark chapters. A 25-minute focus timer records completed sessions. Keep the current page open while using that timer; navigating to another page resets it.

The initial planner has three starter tasks you can edit by deleting and replacing them. Task completion, completed guides and submitted tests count as study activity for streaks.

## Data and scope

Progress, plans, bookmarks, focus minutes and the latest 100 completed attempts are saved in localStorage in the current browser. There is no account system, backend or cross-device sync. Separate students should use separate browser profiles or devices. Clearing site data clears the workspace. Export the result history as CSV when needed. Storage must be permitted for persistence; private or restricted browsing can limit it.

This is a **starter revision and practice website**, not the complete NEET/JEE syllabus, an official exam simulator, or an official previous-year question collection. Full exam-length papers and additional advanced questions can be added to the question bank.

## Customise

- `assets/data.js`: question bank and guide content. In each source question, the first option is the correct answer; runtime shuffling handles presentation.
- `assets/app.js`: navigation shell, rendering, storage, planner, tests and scoring.
- `assets/style.css`: responsive styles. The visual direction follows a 70–20–10 hierarchy: warm neutral surfaces, forest/sage secondary colours, and restrained orange accents. No gradients.
- `assets/favicon.svg`: local icon. All illustrations and interface icons are inline SVG.

## Checks performed

Automated Chromium checks covered all six pages; subject switching; chapter completion; bookmarks; task persistence; question uniqueness; reshuffling; correct/incorrect/skipped marking; option selection; quiz refresh recovery; timed submission; saved result review; focus-session completion; search; and horizontal overflow at 360, 768 and 1280 pixel viewport widths. The desktop and mobile overview were also visually inspected.
